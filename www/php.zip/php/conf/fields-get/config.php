<?php

$conf['class'] = 'FieldsGet';
