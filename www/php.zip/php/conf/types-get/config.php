<?php

$conf['class'] = 'TypesGet';
