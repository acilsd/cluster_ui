<?php

$conf['class'] = 'ObjectGet';
