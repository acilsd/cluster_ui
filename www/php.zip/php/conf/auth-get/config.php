<?php

$conf['class'] = 'AuthGet';
