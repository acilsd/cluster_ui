<?php

$conf['class'] = 'RestPost';

