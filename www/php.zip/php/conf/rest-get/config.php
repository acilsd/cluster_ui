<?php

$conf['class'] = 'RestGet';
