<?php

$conf['class'] = 'FieldsPost';
