<?php

$conf['class'] = 'AuthPost';
