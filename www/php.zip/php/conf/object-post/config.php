<?php

$conf['class'] = 'ObjectPost';
