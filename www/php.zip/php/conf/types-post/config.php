<?php

$conf['class'] = 'TypesPost';

